# tessconfigs
Tesseract Config files
